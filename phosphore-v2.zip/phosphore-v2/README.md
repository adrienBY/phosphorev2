# Phosphore v2

3D wireframes traced like an XY oscilloscope on the Nothing Glyph Matrix
(Phone (4a) Pro 13×13, also Phone (3) 25×25).

## What's new in v2
- **Background playback**: keeps running on the matrix after you leave the app
  (foreground service with a Next / Stop notification), optionally with the screen off,
  with a sleep timer.
- **25 traces** in three groups:
  - Solids: Cube, Tetrahedron, Octahedron, Icosahedron, Dodecahedron, Cuboctahedron,
    Stella octangula, Pyramid, Hex prism
  - Curves: Trefoil, Coil, Torus, Globe, Gyroscope, Atom, Seam, Lissajous, Spirograph,
    Möbius, DNA, Heart, Lorenz
  - Animated: Tesseract (4D), Wave (rippling surface), Clock (live time, oscilloscope-clock style)
- **Presets**: Classic, Vector, Slow draw, Afterglow, Analog, Turntable
- **New controls**: spin mode (tumble / turntable / still), size, contrast, breathing,
  LED brightness, invert, mirror, rotate output, shuffle, more auto-change intervals,
  reset to defaults.

## Build (no PC)
Upload `phosphore-v2.zip` to the repo root and add `.github/workflows/build.yml`
(it unzips, fetches the Glyph Matrix SDK, builds, uploads `phosphore-apk`).
Same package name and signing key as v1, so it installs over v1 and keeps your settings.

## Notes
- Background playback uses `setAppMatrixFrame`. Glyph Toys and system Glyph events
  have priority, so flipping the phone (Always-on toy) or a notification glyph will
  take over the matrix while they run.
- "Keep playing with the screen off" holds a partial wake lock until the sleep timer
  ends; that costs battery.
