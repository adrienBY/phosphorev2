package com.adrienby.phosphore

import android.content.ComponentName
import android.content.Context
import android.os.Handler
import android.os.Looper
import com.nothing.ketchum.GlyphMatrixManager

/** App-side (foreground) access to the matrix. Uses setAppMatrixFrame so it never fights a toy. */
class GlyphLink(context: Context, private val onStatus: (String) -> Unit) {

    private val app = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private var gm: GlyphMatrixManager? = null

    @Volatile var ready = false
        private set

    private val callback = object : GlyphMatrixManager.Callback {
        override fun onServiceConnected(name: ComponentName?) {
            try {
                gm?.register(Device.target)
                ready = true
                status("Live on the Glyph Matrix · ${Device.matrixLength}×${Device.matrixLength}")
            } catch (t: Throwable) {
                ready = false
                status("Glyph service refused registration: ${t.message ?: t.javaClass.simpleName}")
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            ready = false
            status("Glyph service disconnected")
        }
    }

    fun connect() {
        if (gm != null) return
        if (!Device.hasMatrix) {
            status("No Glyph Matrix on this device: preview only")
            return
        }
        try {
            val m = GlyphMatrixManager.getInstance(app)
            gm = m
            m.init(callback)
            status("Connecting to the Glyph Matrix…")
        } catch (t: Throwable) {
            gm = null
            status("Couldn't reach the Glyph service: ${t.message ?: t.javaClass.simpleName}")
        }
    }

    fun push(frame: IntArray) {
        if (!ready) return
        try { gm?.setAppMatrixFrame(frame) } catch (_: Throwable) { }
    }

    fun release() {
        ready = false
        val m = gm ?: return
        gm = null
        try { m.closeAppMatrix() } catch (_: Throwable) { }
        try { m.unInit() } catch (_: Throwable) { }
    }

    private fun status(s: String) = main.post { onStatus(s) }
}
