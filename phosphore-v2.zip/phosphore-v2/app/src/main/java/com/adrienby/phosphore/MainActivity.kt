package com.adrienby.phosphore

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Choreographer
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.adrienby.phosphore.engine.ScopeSettings
import com.adrienby.phosphore.engine.ScopeSettings.Companion as K
import com.adrienby.phosphore.engine.Shapes
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private val n = Device.matrixLength
    private val levels = FloatArray(n * n)
    private val mask = com.adrienby.phosphore.engine.ScopeEngine(n).mask
    private var settings = ScopeSettings()

    private lateinit var preview: MatrixView
    private lateinit var status: TextView
    private val shapeChips = HashMap<Int, TextView>()
    private val refreshers = ArrayList<() -> Unit>()

    private val main = Handler(Looper.getMainLooper())
    private val saveTask = Runnable { SettingsStore.save(this, settings) }

    private var player: PlayerService? = null
    private var bound = false
    private var running = false
    private var shownShape = -1

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val p = (binder as PlayerService.LocalBinder).service
            player = p
            p.apply(settings)
            p.attachUi { status.text = it }
        }
        override fun onServiceDisconnected(name: ComponentName?) { player = null }
    }

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(now: Long) {
            if (!running) return
            player?.let {
                it.snapshot(levels)
                preview.update(levels)
                if (it.currentShape != shownShape) highlightShape(it.currentShape)
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = SettingsStore.load(this)
        setContentView(buildUi())
        if (settings.background) askNotificationPermission()
    }

    override fun onStart() {
        super.onStart()
        syncForeground()
        bound = bindService(Intent(this, PlayerService::class.java), conn, Context.BIND_AUTO_CREATE)
        running = true
        Choreographer.getInstance().postFrameCallback(frame)
    }

    override fun onStop() {
        running = false
        Choreographer.getInstance().removeFrameCallback(frame)
        player?.let { settings = settings.copy(shape = it.currentShape) }
        main.removeCallbacks(saveTask)
        SettingsStore.save(this, settings)
        player?.detachUi()
        if (bound) { unbindService(conn); bound = false }
        player = null
        super.onStop()
    }

    /** Foreground playback exists only when the user wants the matrix to outlive the app. */
    private fun syncForeground() {
        if (settings.mirror && settings.background) {
            try {
                startForegroundService(Intent(this, PlayerService::class.java).setAction(PlayerService.ACTION_PLAY))
            } catch (t: Throwable) {
                Toast.makeText(this, "Couldn't start background playback: ${t.message}", Toast.LENGTH_LONG).show()
            }
        } else {
            player?.leaveForeground()
        }
    }

    private fun update(s: ScopeSettings) {
        val old = settings
        settings = s
        player?.apply(s)
        if (old.mirror != s.mirror || old.background != s.background) syncForeground()
        if (s.background && !old.background) askNotificationPermission()
        main.removeCallbacks(saveTask)
        main.postDelayed(saveTask, 150)
    }

    private fun applyAll(s: ScopeSettings) {
        update(s)
        refreshers.forEach { it() }
    }

    private fun askNotificationPermission() {
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    // ------------------------------------------------------------------ UI

    private fun buildUi(): View {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Palette.PANEL)
            isVerticalScrollBarEnabled = false
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(32))
        }
        scroll.addView(col)
        scroll.setOnApplyWindowInsetsListener { v, insets ->
            val b = insets.getInsets(WindowInsets.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        head.addView(text("Phosphore", 30f, Palette.INK, bold = true))
        head.addView(text("v2", 15f, Palette.ACTIVE).apply { setPadding(dp(8), 0, 0, dp(5)) })
        col.addView(head)
        col.addView(text("XY oscilloscope for the Glyph Matrix", 14f, Palette.INK_DIM).apply {
            setPadding(0, dp(2), 0, dp(18))
        })

        preview = MatrixView(this, n, mask).apply {
            onDrag = { dy, dpch, dt -> player?.drag(dy, dpch, dt) }
            onRelease = { player?.release() }
        }
        col.addView(preview, LinearLayout.LayoutParams(dp(300), dp(300)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
        })
        col.addView(text("Drag the screen to spin the trace", 12f, Palette.INK_DIM).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(8), 0, 0)
        }, matchWrap())
        status = text("Starting…", 13f, Palette.ACTIVE).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(4), 0, dp(4))
        }
        col.addView(status, matchWrap())

        // ---------------------------------------------------------------- presets
        section(col, "Presets")
        col.addView(text("Sets the look; keeps your trace and Glyph Matrix options.", 12f, Palette.INK_DIM)
            .apply { setPadding(0, 0, 0, dp(6)) })
        val presetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        K.PRESETS.forEach { (name, p) -> presetRow.addView(chip(name) { applyAll(settings.withLook(p)) }) }
        col.addView(scrollRow(presetRow), matchWrap())

        // ---------------------------------------------------------------- trace
        section(col, "Trace")
        for (cat in Shapes.CATEGORIES) {
            col.addView(text(cat, 13f, Palette.INK_DIM).apply { setPadding(0, dp(6), 0, dp(4)) })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (i in Shapes.indicesOf(cat)) {
                val c = chip(Shapes.all[i].name) { update(settings.copy(shape = i)); highlightShape(i) }
                shapeChips[i] = c
                row.addView(c)
            }
            col.addView(scrollRow(row), matchWrap())
        }
        highlightShape(settings.shape)
        options(col, "Change trace automatically",
            listOf("Off" to 0, "10 s" to 10, "30 s" to 30, "1 min" to 60, "5 min" to 300),
            { it.autoCycle }, { s, v -> s.copy(autoCycle = v) })
        toggle(col, "Shuffle the order", { it.shuffle }, { s, v -> s.copy(shuffle = v) })

        // ---------------------------------------------------------------- motion
        section(col, "Motion")
        options(col, "Spin",
            listOf("Tumble" to K.SPIN_TUMBLE, "Turntable" to K.SPIN_TURNTABLE, "Still" to K.SPIN_STILL),
            { it.spinMode }, { s, v -> s.copy(spinMode = v) })
        knob(col, "Rotation speed", { it.rotation }, { s, v -> s.copy(rotation = v) },
            { "%.1f rpm".format(K.rotationRadPerSec(it) * 60f / 6.2832f) })
        knob(col, "Size", { it.size }, { s, v -> s.copy(size = v) },
            { "%d%%".format((K.sizeMul(it) * 100).roundToInt()) })

        // ---------------------------------------------------------------- beam
        section(col, "Beam")
        knob(col, "Sweep", { it.sweep }, { s, v -> s.copy(sweep = v) }) {
            val hz = K.sweepHz(it); if (hz < 10f) "%.1f Hz".format(hz) else "%d Hz".format(hz.roundToInt())
        }
        knob(col, "Bandwidth", { it.bandwidth }, { s, v -> s.copy(bandwidth = v) },
            { "%d× sweep".format(K.bandwidthHarmonics(it).roundToInt()) })
        knob(col, "Focus", { it.focus }, { s, v -> s.copy(focus = v) },
            { "%.2f LED".format(K.focusSigma(it)) })

        // ---------------------------------------------------------------- phosphor
        section(col, "Phosphor")
        knob(col, "Persistence", { it.persistence }, { s, v -> s.copy(persistence = v) }) {
            val sec = K.persistenceSec(it); if (sec < 1f) "%d ms".format((sec * 1000).roundToInt()) else "%.1f s".format(sec)
        }
        knob(col, "Intensity", { it.intensity }, { s, v -> s.copy(intensity = v) }, ::pct)
        knob(col, "Contrast", { it.contrast }, { s, v -> s.copy(contrast = v) },
            { "γ %.1f".format(K.gamma(it)) })
        knob(col, "Depth shading", { it.depth }, { s, v -> s.copy(depth = v) }, ::pct)
        knob(col, "Noise", { it.noise }, { s, v -> s.copy(noise = v) }, ::pct)
        knob(col, "Breathing", { it.breathing }, { s, v -> s.copy(breathing = v) }, ::pct)

        // ---------------------------------------------------------------- matrix
        section(col, "Glyph Matrix")
        toggle(col, "Show on the back of the phone", { it.mirror }, { s, v -> s.copy(mirror = v) })
        toggle(col, "Keep playing after you leave the app", { it.background }, { s, v -> s.copy(background = v) })
        toggle(col, "Keep playing with the screen off", { it.screenOff }, { s, v -> s.copy(screenOff = v) })
        options(col, "Stop after leaving the app",
            listOf("15 min" to 15, "30 min" to 30, "1 h" to 60, "3 h" to 180, "Never" to 0),
            { it.sleepMinutes }, { s, v -> s.copy(sleepMinutes = v) })
        knob(col, "LED brightness", { it.brightness }, { s, v -> s.copy(brightness = v) }, ::pct)
        options(col, "Frame rate", listOf("15 fps" to 15, "30 fps" to 30, "60 fps" to 60),
            { it.matrixFps }, { s, v -> s.copy(matrixFps = v) })
        options(col, "Rotate output", listOf("0°" to 0, "90°" to 90, "180°" to 180, "270°" to 270),
            { it.rotate }, { s, v -> s.copy(rotate = v) })
        toggle(col, "Mirror horizontally", { it.flipX }, { s, v -> s.copy(flipX = v) })
        toggle(col, "Invert (dark trace on a lit disc)", { it.invert }, { s, v -> s.copy(invert = v) })

        // ---------------------------------------------------------------- always-on toy
        section(col, "Always-on Glyph Toy")
        options(col, "Run time each time it starts",
            listOf("1 min" to 1, "5 min" to 5, "15 min" to 15, "No limit" to 0),
            { it.aodMinutes }, { s, v -> s.copy(aodMinutes = v) })
        val btn = Button(this).apply {
            text = "Use as Always-on Glyph Toy"
            isAllCaps = false
            textSize = 15f
            setTextColor(Palette.SCREEN)
            background = GradientDrawable().apply { setColor(Palette.ACTIVE); cornerRadius = dp(6).toFloat() }
            setOnClickListener { openToySettings() }
        }
        col.addView(btn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply {
            topMargin = dp(16)
        })
        col.addView(text(
            if (n == 13)
                "Settings › Glyph Interface › Flip to Glyph › Always-on Glyph Toy, then pick Phosphore. It plays your current settings whenever the phone lies face down."
            else
                "Add Phosphore to your Glyph Toys. A long press on the Glyph Button switches trace.",
            12f, Palette.INK_DIM
        ).apply { setPadding(0, dp(8), 0, 0); setLineSpacing(0f, 1.25f) }, matchWrap())

        // ---------------------------------------------------------------- reset
        val reset = Button(this).apply {
            text = "Reset everything to defaults"
            isAllCaps = false
            textSize = 14f
            setTextColor(Palette.INK)
            background = GradientDrawable().apply {
                setColor(Palette.PANEL); setStroke(dp(1), Palette.RULE); cornerRadius = dp(6).toFloat()
            }
            setOnClickListener { applyAll(ScopeSettings()); highlightShape(0) }
        }
        col.addView(reset, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)).apply {
            topMargin = dp(28)
        })
        col.addView(text("Phosphore 2.0", 12f, Palette.INK_DIM).apply {
            gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, dp(14), 0, 0)
        }, matchWrap())

        return scroll
    }

    private fun highlightShape(i: Int) {
        shownShape = i
        shapeChips.forEach { (k, c) -> styleChip(c, k == i) }
    }

    private fun openToySettings() {
        if (n == 25) {
            try {
                startActivity(Intent().setComponent(ComponentName(
                    "com.nothing.thirdparty",
                    "com.nothing.thirdparty.matrix.toys.manager.ToysManagerActivity"
                )))
                return
            } catch (_: Throwable) { }
        }
        try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Throwable) { }
        Toast.makeText(this, "Glyph Interface › Flip to Glyph › Always-on Glyph Toy", Toast.LENGTH_LONG).show()
    }

    // ------------------------------------------------------------------ widgets

    private fun section(col: LinearLayout, title: String) {
        col.addView(View(this).apply { setBackgroundColor(Palette.RULE) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)).apply {
                topMargin = dp(22); bottomMargin = dp(12)
            })
        col.addView(text(title, 17f, Palette.INK, bold = true).apply { setPadding(0, 0, 0, dp(4)) })
    }

    private fun knob(
        col: LinearLayout, label: String,
        get: (ScopeSettings) -> Float, set: (ScopeSettings, Float) -> ScopeSettings,
        fmt: (Float) -> String,
    ) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, 0)
        }
        val value = text(fmt(get(settings)), 14f, Palette.ACTIVE).apply {
            fontFeatureSettings = "tnum"
            gravity = Gravity.END
        }
        row.addView(text(label, 15f, Palette.INK), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(value)
        col.addView(row, matchWrap())
        val bar = SeekBar(this).apply {
            max = 1000
            progress = (get(settings) * 1000).roundToInt()
            progressTintList = ColorStateList.valueOf(Palette.ACTIVE)
            progressBackgroundTintList = ColorStateList.valueOf(Palette.RULE)
            thumbTintList = ColorStateList.valueOf(Palette.INK)
            setPadding(dp(2), dp(6), dp(2), dp(6))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    val v = p / 1000f
                    value.text = fmt(v)
                    update(set(settings, v))
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }
        col.addView(bar, matchWrap())
        refreshers.add {
            val v = get(settings)
            bar.progress = (v * 1000).roundToInt()
            value.text = fmt(v)
        }
    }

    private fun toggle(
        col: LinearLayout, label: String,
        get: (ScopeSettings) -> Boolean, set: (ScopeSettings, Boolean) -> ScopeSettings,
    ) {
        val sw = Switch(this).apply {
            text = label
            setTextColor(Palette.INK)
            textSize = 15f
            isChecked = get(settings)
            thumbTintList = ColorStateList.valueOf(Palette.INK)
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Palette.ACTIVE, Palette.RULE)
            )
            setPadding(0, dp(10), 0, dp(4))
        }
        var silent = false
        sw.setOnCheckedChangeListener { _, on -> if (!silent) update(set(settings, on)) }
        col.addView(sw, matchWrap())
        refreshers.add { silent = true; sw.isChecked = get(settings); silent = false }
    }

    private fun options(
        col: LinearLayout, label: String, items: List<Pair<String, Int>>,
        get: (ScopeSettings) -> Int, set: (ScopeSettings, Int) -> ScopeSettings,
    ) {
        col.addView(text(label, 15f, Palette.INK).apply { setPadding(0, dp(12), 0, dp(6)) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val chips = ArrayList<TextView>()
        fun paint() { val cur = get(settings); chips.forEachIndexed { k, c -> styleChip(c, items[k].second == cur) } }
        items.forEach { (name, v) ->
            val c = chip(name) { update(set(settings, v)); paint() }
            chips.add(c)
            row.addView(c)
        }
        paint()
        col.addView(scrollRow(row), matchWrap())
        refreshers.add { paint() }
    }

    private fun scrollRow(row: LinearLayout) = HorizontalScrollView(this).apply {
        isHorizontalScrollBarEnabled = false
        addView(row)
    }

    private fun chip(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 14f
        typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        isClickable = true
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { rightMargin = dp(8); bottomMargin = dp(4) }
        styleChip(this, false)
    }

    private fun styleChip(c: TextView, on: Boolean) {
        c.background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            if (on) setColor(Palette.ACTIVE) else { setColor(Palette.PANEL); setStroke(dp(1), Palette.RULE) }
        }
        c.setTextColor(if (on) Palette.SCREEN else Palette.INK)
    }

    private fun text(s: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        typeface = Typeface.create("sans-serif-condensed", if (bold) Typeface.BOLD else Typeface.NORMAL)
    }

    private fun pct(v: Float) = "%d%%".format((v * 100).roundToInt())

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()
}
