package com.adrienby.phosphore.engine

import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * XY-oscilloscope simulation on a tiny LED grid.
 *
 *  - The beam sweeps the shape's path at [scanHz] cycles per second (path-length parametrised,
 *    blanked between strokes, with a retrace when a stroke doesn't close on itself).
 *  - Beam deflection goes through a 2nd-order low-pass (the "amplifier bandwidth"): corners round
 *    off and ring slightly, and the beam lingers where it slows down — so vertices glow brighter,
 *    exactly like a real scope.
 *  - Energy is splatted with a normalised gaussian (the "focus") into a phosphor buffer that
 *    decays exponentially ("persistence").
 *
 * Pure Kotlin, no Android dependency, so it runs identically in the app and in the toy service.
 */
class ScopeEngine(val size: Int = 13) {

    val cells = size * size
    val phosphor = FloatArray(cells)
    val mask = BooleanArray(cells)

    private val c = (size - 1) / 2f
    private val radius: Float

    // ---- parameters (physical units)
    private var rotSpeed = 1f
    private var scanHz = 40f
    private var tau = 0.25f
    private var sigma = 0.6f
    private var omega = 300f
    private var gain = 1f
    private var noise = 0.1f
    private var depthCue = 0.5f
    private var autoCycle = 0f
    private var shuffle = false
    private var spinMode = ScopeSettings.SPIN_TUMBLE
    private var sizeMul = 1f
    private var gamma = 1.6f
    private var breathing = 0f
    private var brightness = 1f
    private var invert = false
    private val outMap = IntArray(cells) { it }
    private var mapFlip = false
    private var mapRot = 0

    // ---- state
    var shapeIndex = 0
        private set
    private var appliedShape = -1
    private var time = 0f
    private var cycleTimer = 0f
    private var phase = 0f
    private var ax = 0.45f; private var ay = 0.6f; private var az = 0f
    private var userYaw = 0f; private var userPitch = 0f
    private var velYaw = 0f; private var velPitch = 0f
    private var dragging = false
    private var bx = 0f; private var by = 0f; private var bvx = 0f; private var bvy = 0f
    private val rng = Random(7)
    private var timelineDirty = true

    // ---- timeline (flattened segments)
    private var segN = 0
    private var segA = FloatArray(0)
    private var segB = FloatArray(0)
    private var segStart = FloatArray(0)
    private var segLen = FloatArray(0)
    private var segOn = BooleanArray(0)
    private var totalLen = 1f

    // ---- gaussian LUT
    private val lut = FloatArray(LUT_N) { exp(-it * LUT_MAX / LUT_N) }
    private val wbuf = FloatArray(49)

    private val m0 = FloatArray(9)
    private val m1 = FloatArray(9)
    private val mu = FloatArray(9)

    init {
        val r2 = when (size) { 13 -> 42f; 25 -> 153f; else -> (size / 2f) * (size / 2f) }
        for (y in 0 until size) for (x in 0 until size) {
            val dx = x - c; val dy = y - c
            mask[y * size + x] = dx * dx + dy * dy <= r2
        }
        radius = sqrt(r2) - 0.55f
        bx = c; by = c
    }

    fun apply(s: ScopeSettings) {
        rotSpeed = ScopeSettings.rotationRadPerSec(s.rotation)
        scanHz = ScopeSettings.sweepHz(s.sweep)
        tau = ScopeSettings.persistenceSec(s.persistence)
        sigma = ScopeSettings.focusSigma(s.focus)
        omega = ScopeSettings.bandwidthOmega(s.bandwidth)
        gain = ScopeSettings.gain(s.intensity)
        noise = s.noise
        depthCue = s.depth
        autoCycle = s.autoCycle.toFloat()
        shuffle = s.shuffle
        spinMode = s.spinMode
        sizeMul = ScopeSettings.sizeMul(s.size)
        gamma = ScopeSettings.gamma(s.contrast)
        breathing = s.breathing
        brightness = s.brightness.coerceIn(0f, 1f)
        invert = s.invert
        if (s.flipX != mapFlip || s.rotate != mapRot) buildOutMap(s.flipX, s.rotate)
        if (s.shape != appliedShape) { appliedShape = s.shape; setShape(s.shape) }
    }

    fun setShape(i: Int) {
        shapeIndex = Math.floorMod(i, Shapes.all.size)
        timelineDirty = true
        phase = 0f
        cycleTimer = 0f
    }

    fun nextShape() {
        val count = Shapes.all.size
        if (shuffle && count > 1) {
            var r = rng.nextInt(count - 1)
            if (r >= shapeIndex) r++
            setShape(r)
        } else setShape(shapeIndex + 1)
    }

    fun previousShape() = setShape(shapeIndex - 1)

    /** Direct manipulation: radians to add. */
    fun drag(dYaw: Float, dPitch: Float, dt: Float) {
        dragging = true
        userYaw += dYaw; userPitch += dPitch
        if (dt > 0f) {
            velYaw = velYaw * 0.5f + 0.5f * dYaw / dt
            velPitch = velPitch * 0.5f + 0.5f * dPitch / dt
        }
    }

    fun release() { dragging = false }

    fun step(dtIn: Float) {
        val dt = dtIn.coerceIn(0f, 0.1f)
        if (dt <= 0f) return
        time += dt

        if (autoCycle > 0f) {
            cycleTimer += dt
            if (cycleTimer >= autoCycle) nextShape()
        }
        val shape = Shapes.all[shapeIndex]
        if (timelineDirty || shape.animated) {
            buildTimeline(shape.strokes(time))
            timelineDirty = false
        }

        // phosphor decay
        val decay = exp(-dt / tau)
        for (i in 0 until cells) phosphor[i] *= decay

        // rotation at frame start / end (interpolated per sample = honest motion smear)
        val spins = shape.spins && spinMode != ScopeSettings.SPIN_STILL
        autoAngles(shape.spins)
        rotation(rax, ray, raz, userYaw, userPitch, m0)
        if (spins) {
            if (spinMode == ScopeSettings.SPIN_TURNTABLE) {
                ay += dt * rotSpeed
            } else {
                ax += dt * rotSpeed * 0.62f
                ay += dt * rotSpeed
                az += dt * rotSpeed * 0.23f
            }
        }
        if (!dragging) {
            userYaw += velYaw * dt; userPitch += velPitch * dt
            val damp = exp(-dt * 2.2f)
            velYaw *= damp; velPitch *= damp
        }
        autoAngles(shape.spins)
        rotation(rax, ray, raz, userYaw, userPitch, m1)

        // sampling budget
        val screenLen = totalLen * radius * sizeMul
        val spc = (screenLen * 3.2f).coerceIn(160f, 4000f)          // samples per sweep cycle
        val cycles = scanHz * dt
        val ideal = cycles * spc
        val cap = min(BUDGET_PER_SEC * dt, 2f * spc)
        val n: Int
        val dPhase: Float
        if (ideal <= cap) {
            n = max(1, ideal.roundToInt())
            dPhase = cycles / n
        } else {
            n = max(1, cap.toInt())
            dPhase = 1f / spc
        }
        val breathe = if (breathing > 0f) 1f - breathing * 0.7f * (0.5f - 0.5f * cos(time * 1.6f)) else 1f
        val e = gain * breathe * screenLen * dt / n

        // filter in sweep-cycle time
        val iters = max(1, ceil(omega * dPhase / 0.45f).toInt())
        val h = dPhase / iters
        val w2 = omega * omega
        val zw2 = 2f * ZETA * omega

        val inv2s2 = 1f / (2f * sigma * sigma)
        val sr = min(3, ceil(2.4f * sigma).toInt())
        val persp = PERSP
        val scale = radius * (persp - 1f) * sizeMul
        val jit = noise * 0.22f
        val hum = noise * 0.30f

        var seg = locate(phase * totalLen)
        for (k in 0 until n) {
            phase += dPhase
            if (phase >= 1f) { phase -= 1f; seg = 0 }
            val s = phase * totalLen
            while (seg < segN - 1 && segStart[seg + 1] <= s) seg++
            val f = if (segLen[seg] > 1e-6f) ((s - segStart[seg]) / segLen[seg]).coerceIn(0f, 1f) else 0f
            val i3 = seg * 3
            val px = segA[i3] + (segB[i3] - segA[i3]) * f
            val py = segA[i3 + 1] + (segB[i3 + 1] - segA[i3 + 1]) * f
            val pz = segA[i3 + 2] + (segB[i3 + 2] - segA[i3 + 2]) * f

            // interpolated rotation
            val tf = (k + 0.5f) / n
            for (j in 0 until 9) mu[j] = m0[j] + (m1[j] - m0[j]) * tf
            val rx = mu[0] * px + mu[1] * py + mu[2] * pz
            val ry = mu[3] * px + mu[4] * py + mu[5] * pz
            val rz = mu[6] * px + mu[7] * py + mu[8] * pz

            val pk = scale / (persp - rz)
            var tx = c + rx * pk
            var ty = c - ry * pk
            if (noise > 0f) {
                val tReal = time - dt + dt * tf
                tx += (rng.nextFloat() - 0.5f) * jit + hum * sin(tReal * 314.159f) * 0.5f
                ty += (rng.nextFloat() - 0.5f) * jit + hum * sin(tReal * 3.7f + 1f) * 0.3f
            }

            for (it in 0 until iters) {
                bvx += (w2 * (tx - bx) - zw2 * bvx) * h
                bvy += (w2 * (ty - by) - zw2 * bvy) * h
                bx += bvx * h
                by += bvy * h
            }

            if (segOn[seg]) {
                val dm = 1f - depthCue * 0.75f * (0.5f - 0.5f * rz.coerceIn(-1f, 1f))
                var en = e * dm
                if (noise > 0f) en *= 1f + (rng.nextFloat() - 0.5f) * noise * 0.6f
                splat(bx, by, en, inv2s2, sr)
            }
        }
    }

    /**
     * LED drive levels 0..1, exactly what the matrix shows (gamma, invert, brightness,
     * flip and rotation applied), so the on-screen preview is a faithful twin.
     */
    fun levels(out: FloatArray) {
        val k = 1.15f / tau
        for (i in 0 until cells) {
            out[i] = if (mask[i]) {
                var v = (1f - exp(-phosphor[outMap[i]] * k)).pow(gamma)
                if (invert) v = 1f - v
                v * brightness
            } else 0f
        }
    }

    /** Frame for the Glyph Matrix SDK: 0..4095 per LED, row-major. */
    fun toLed(out: IntArray, scratch: FloatArray) {
        levels(scratch)
        for (i in 0 until cells) out[i] = (scratch[i] * 4095f).roundToInt().coerceIn(0, 4095)
    }

    private fun buildOutMap(flip: Boolean, rot: Int) {
        mapFlip = flip; mapRot = rot
        val last = size - 1
        for (y in 0 until size) for (x in 0 until size) {
            // output pixel (x, y) samples source pixel (sx, sy)
            var sx = x; var sy = y
            when (rot) {
                90 -> { sx = y; sy = last - x }
                180 -> { sx = last - x; sy = last - y }
                270 -> { sx = last - y; sy = x }
            }
            if (flip) sx = last - sx
            outMap[y * size + x] = sy * size + sx
        }
    }

    private var rax = 0f; private var ray = 0f; private var raz = 0f
    private fun autoAngles(spins: Boolean) {
        when {
            !spins -> { rax = 0f; ray = 0f; raz = 0f }
            spinMode == ScopeSettings.SPIN_TURNTABLE -> { rax = 0.38f; ray = ay; raz = 0f }
            else -> { rax = ax; ray = ay; raz = az }
        }
    }

    fun clear() { phosphor.fill(0f) }

    // ------------------------------------------------------------------ internals

    private fun splat(x: Float, y: Float, e: Float, inv2s2: Float, r: Int) {
        val cx = x.roundToInt(); val cy = y.roundToInt()
        var sum = 0f
        var idx = 0
        for (j in -r..r) for (i in -r..r) {
            val dx = cx + i - x; val dy = cy + j - y
            val a = (dx * dx + dy * dy) * inv2s2
            val w = if (a >= LUT_MAX) 0f else lut[(a * (LUT_N / LUT_MAX)).toInt()]
            wbuf[idx++] = w; sum += w
        }
        if (sum <= 1e-6f) return
        val norm = e / sum
        idx = 0
        for (j in -r..r) {
            val gy = cy + j
            for (i in -r..r) {
                val gx = cx + i
                val w = wbuf[idx++]
                if (gx in 0 until size && gy in 0 until size) phosphor[gy * size + gx] += w * norm
            }
        }
    }

    private fun locate(s: Float): Int {
        var lo = 0; var hi = segN - 1
        while (lo < hi) {
            val mid = (lo + hi + 1) ushr 1
            if (segStart[mid] <= s) lo = mid else hi = mid - 1
        }
        return lo
    }

    private fun buildTimeline(strokes: List<FloatArray>) {
        var n = 0
        for (s in strokes) n += max(0, s.size / 3 - 1) + 1
        if (segA.size < n * 3) {
            segA = FloatArray(n * 3); segB = FloatArray(n * 3)
            segStart = FloatArray(n); segLen = FloatArray(n); segOn = BooleanArray(n)
        }
        var k = 0
        var cum = 0f
        fun add(a: FloatArray, ai: Int, b: FloatArray, bi: Int, on: Boolean) {
            val dx = b[bi] - a[ai]; val dy = b[bi + 1] - a[ai + 1]; val dz = b[bi + 2] - a[ai + 2]
            val d = sqrt(dx * dx + dy * dy + dz * dz)
            val len = if (on) d else if (d < 1e-4f) return else d * 0.55f + 0.06f
            val k3 = k * 3
            segA[k3] = a[ai]; segA[k3 + 1] = a[ai + 1]; segA[k3 + 2] = a[ai + 2]
            segB[k3] = b[bi]; segB[k3 + 1] = b[bi + 1]; segB[k3 + 2] = b[bi + 2]
            segStart[k] = cum; segLen[k] = len; segOn[k] = on
            cum += len; k++
        }
        for ((si, s) in strokes.withIndex()) {
            val pts = s.size / 3
            for (j in 0 until pts - 1) add(s, j * 3, s, (j + 1) * 3, true)
            val next = strokes[(si + 1) % strokes.size]
            add(s, (pts - 1) * 3, next, 0, false)
        }
        segN = max(1, k)
        totalLen = max(cum, 1e-3f)
    }

    private fun rotation(ax: Float, ay: Float, az: Float, uy: Float, up: Float, m: FloatArray) {
        // auto tumble R = Rz * Ry * Rx, then user R = Rx(pitch) * Ry(yaw) applied on top
        val cxr = cos(ax); val sxr = sin(ax)
        val cyr = cos(ay); val syr = sin(ay)
        val czr = cos(az); val szr = sin(az)
        val a00 = czr * cyr; val a01 = czr * syr * sxr - szr * cxr; val a02 = czr * syr * cxr + szr * sxr
        val a10 = szr * cyr; val a11 = szr * syr * sxr + czr * cxr; val a12 = szr * syr * cxr - czr * sxr
        val a20 = -syr;      val a21 = cyr * sxr;                    val a22 = cyr * cxr
        val cu = cos(uy); val su = sin(uy); val cp = cos(up); val sp = sin(up)
        // U = Rx(p) * Ry(y)
        val u00 = cu;        val u01 = 0f;  val u02 = su
        val u10 = sp * su;   val u11 = cp;  val u12 = -sp * cu
        val u20 = -cp * su;  val u21 = sp;  val u22 = cp * cu
        m[0] = u00 * a00 + u01 * a10 + u02 * a20
        m[1] = u00 * a01 + u01 * a11 + u02 * a21
        m[2] = u00 * a02 + u01 * a12 + u02 * a22
        m[3] = u10 * a00 + u11 * a10 + u12 * a20
        m[4] = u10 * a01 + u11 * a11 + u12 * a21
        m[5] = u10 * a02 + u11 * a12 + u12 * a22
        m[6] = u20 * a00 + u21 * a10 + u22 * a20
        m[7] = u20 * a01 + u21 * a11 + u22 * a21
        m[8] = u20 * a02 + u21 * a12 + u22 * a22
    }

    companion object {
        private const val LUT_N = 1024
        private const val LUT_MAX = 9f
        private const val ZETA = 0.62f          // slightly under-damped: corners ring a little
        private const val PERSP = 4.0f          // camera distance in shape radii
        private const val BUDGET_PER_SEC = 200_000f
    }
}
