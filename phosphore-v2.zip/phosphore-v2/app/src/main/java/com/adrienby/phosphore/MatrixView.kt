package com.adrienby.phosphore

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.pow

/** On-screen twin of the Glyph Matrix: one dot per LED, drawn at the LED's real drive level. */
class MatrixView(context: Context, private val n: Int, private val mask: BooleanArray) : View(context) {

    private val levels = FloatArray(n * n)

    var onDrag: ((dYaw: Float, dPitch: Float, dt: Float) -> Unit)? = null
    var onRelease: (() -> Unit)? = null

    private val bezel = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Palette.SCREEN }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Palette.RULE; style = Paint.Style.STROKE; strokeWidth = 2f
    }
    private val dark = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Palette.LED_OFF }
    private val core = Paint(Paint.ANTI_ALIAS_FLAG)
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG)

    fun update(src: FloatArray) {
        System.arraycopy(src, 0, levels, 0, min(src.size, levels.size))
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, w)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val cx = w / 2f
        canvas.drawCircle(cx, cx, w / 2f - 1f, bezel)
        canvas.drawCircle(cx, cx, w / 2f - 6f, ring)
        val pitch = w * 0.9f / n
        val r = pitch * 0.34f
        val c = (n - 1) / 2f
        for (y in 0 until n) for (x in 0 until n) {
            val i = y * n + x
            if (!mask[i]) continue
            val px = cx + (x - c) * pitch
            val py = cx + (y - c) * pitch
            // LED luminance is linear in drive; the screen is sRGB, so encode before drawing.
            val v = levels[i].coerceIn(0f, 1f).pow(1f / 2.2f)
            if (v < 0.02f) { canvas.drawCircle(px, py, r, dark); continue }
            halo.color = argb((v * v * 90f).toInt(), 0xF2, 0xF6, 0xF7)
            canvas.drawCircle(px, py, r * 1.75f, halo)
            core.color = mix(Palette.LED_OFF, Palette.LED_ON, v)
            canvas.drawCircle(px, py, r, core)
        }
    }

    private var lx = 0f
    private var ly = 0f
    private var lt = 0L

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                lx = e.x; ly = e.y; lt = e.eventTime
                onDrag?.invoke(0f, 0f, 0f)
            }
            MotionEvent.ACTION_MOVE -> {
                val k = (PI / width).toFloat()
                val dt = (e.eventTime - lt).coerceAtLeast(1L) / 1000f
                onDrag?.invoke((e.x - lx) * k, (e.y - ly) * k, dt)
                lx = e.x; ly = e.y; lt = e.eventTime
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                onRelease?.invoke()
            }
        }
        return true
    }

    private fun argb(a: Int, r: Int, g: Int, b: Int) =
        (a.coerceIn(0, 255) shl 24) or (r shl 16) or (g shl 8) or b

    private fun mix(a: Int, b: Int, t: Float): Int {
        fun ch(s: Int) = s and 0xFF
        val r = (ch(a shr 16) + (ch(b shr 16) - ch(a shr 16)) * t).toInt()
        val g = (ch(a shr 8) + (ch(b shr 8) - ch(a shr 8)) * t).toInt()
        val bl = (ch(a) + (ch(b) - ch(a)) * t).toInt()
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
    }
}

object Palette {
    const val PANEL = 0xFF27333C.toInt()      // instrument front panel, slate
    const val SCREEN = 0xFF141B20.toInt()     // CRT surround
    const val RULE = 0xFF3A4852.toInt()
    const val INK = 0xFFD9E1E6.toInt()
    const val INK_DIM = 0xFF8C9BA6.toInt()
    const val ACTIVE = 0xFF62B4E2.toInt()     // Tek-blue for the selected control
    const val LED_OFF = 0xFF1F292F.toInt()
    const val LED_ON = 0xFFF4F8FA.toInt()
}
