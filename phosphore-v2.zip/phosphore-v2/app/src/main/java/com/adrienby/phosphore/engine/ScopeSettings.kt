package com.adrienby.phosphore.engine

import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.pow

/** Knobs are stored normalised to 0..1; mapping to physical units lives in the companion. */
data class ScopeSettings(
    // trace
    val shape: Int = 0,
    val autoCycle: Int = 0,          // seconds, 0 = off
    val shuffle: Boolean = false,
    // motion
    val spinMode: Int = SPIN_TUMBLE,
    val rotation: Float = 0.35f,
    val size: Float = 0.5f,
    // beam
    val sweep: Float = 0.70f,
    val bandwidth: Float = 0.55f,
    val focus: Float = 0.22f,
    // phosphor
    val persistence: Float = 0.45f,
    val intensity: Float = 0.55f,
    val contrast: Float = 0.375f,
    val depth: Float = 0.50f,
    val noise: Float = 0.12f,
    val breathing: Float = 0f,
    // glyph matrix output
    val mirror: Boolean = true,
    val background: Boolean = true,
    val screenOff: Boolean = true,
    val sleepMinutes: Int = 30,      // 0 = never
    val matrixFps: Int = 30,
    val brightness: Float = 1f,
    val invert: Boolean = false,
    val flipX: Boolean = false,
    val rotate: Int = 0,             // 0, 90, 180, 270
    // always-on toy
    val aodMinutes: Int = 5,         // 0 = no limit
) {
    /** Look-related knobs from [p], keeping this one's trace and output options. */
    fun withLook(p: ScopeSettings) = copy(
        spinMode = p.spinMode, rotation = p.rotation, size = p.size,
        sweep = p.sweep, bandwidth = p.bandwidth, focus = p.focus,
        persistence = p.persistence, intensity = p.intensity, contrast = p.contrast,
        depth = p.depth, noise = p.noise, breathing = p.breathing,
    )

    companion object {
        const val SPIN_TUMBLE = 0
        const val SPIN_TURNTABLE = 1
        const val SPIN_STILL = 2

        fun rotationRadPerSec(v: Float) = 3f * v.pow(1.5f)
        fun sizeMul(v: Float) = 0.7f + 0.6f * v
        fun sweepHz(v: Float) = 0.15f * exp(v * ln(400f / 0.15f))
        fun persistenceSec(v: Float) = 0.03f * exp(v * ln(100f))
        fun focusSigma(v: Float) = 0.30f + 0.90f * v
        fun bandwidthHarmonics(v: Float) = 4f * exp(v * ln(60f))
        fun bandwidthOmega(v: Float) = (2.0 * PI).toFloat() * bandwidthHarmonics(v)
        fun gain(v: Float) = 0.2f + 2.6f * v * v
        fun gamma(v: Float) = 1f + 1.6f * v

        val PRESETS: List<Pair<String, ScopeSettings>> = listOf(
            "Classic" to ScopeSettings(),
            "Vector" to ScopeSettings(sweep = 0.9f, bandwidth = 0.92f, focus = 0.04f,
                persistence = 0.3f, intensity = 0.62f, contrast = 0.55f, noise = 0f),
            "Slow draw" to ScopeSettings(rotation = 0.2f, sweep = 0.27f, bandwidth = 0.5f,
                persistence = 0.62f, intensity = 0.6f, noise = 0.05f),
            "Afterglow" to ScopeSettings(rotation = 0.42f, sweep = 0.62f, persistence = 0.86f,
                intensity = 0.42f, contrast = 0.5f),
            "Analog" to ScopeSettings(bandwidth = 0.18f, focus = 0.5f, noise = 0.6f,
                breathing = 0.25f, persistence = 0.5f),
            "Turntable" to ScopeSettings(spinMode = SPIN_TURNTABLE, rotation = 0.3f, depth = 0.8f),
        )
    }
}
