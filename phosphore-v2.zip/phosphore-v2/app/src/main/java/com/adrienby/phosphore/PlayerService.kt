package com.adrienby.phosphore

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Binder
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import com.adrienby.phosphore.engine.ScopeEngine
import com.adrienby.phosphore.engine.ScopeSettings
import com.adrienby.phosphore.engine.Shapes
import kotlin.math.min

/**
 * Owns the one engine instance and drives the Glyph Matrix from a render thread.
 *
 * - While the app is open, the activity binds to it and reads frames for the preview.
 * - With "keep playing" on, the activity also starts it as a foreground service, so it
 *   survives the activity being closed and keeps the matrix running (notification with
 *   Next / Stop). Optionally holds a partial wake lock so it keeps going with the screen off.
 */
class PlayerService : Service() {

    inner class LocalBinder : Binder() {
        val service: PlayerService get() = this@PlayerService
    }

    private val binder = LocalBinder()
    private val main = Handler(Looper.getMainLooper())
    private val thread = HandlerThread("phosphore-render").apply { start() }
    private val render = Handler(thread.looper)

    private val n = Device.matrixLength
    private val engine = ScopeEngine(n)
    private val snapshot = FloatArray(n * n)
    private val scratch = FloatArray(n * n)
    private val led = IntArray(n * n)
    private val lock = Any()

    @Volatile private var settings = ScopeSettings()
    @Volatile var currentShape = 0
        private set
    @Volatile private var uiAttached = false
    @Volatile private var detachedAt = 0L

    private var glyph: GlyphLink? = null
    private var statusListener: ((String) -> Unit)? = null
    private var lastStatus = ""
    private var foreground = false
    private var wakeLock: PowerManager.WakeLock? = null

    private var lastNs = 0L
    private var pushAcc = 0f
    @Volatile private var running = false

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val now = System.nanoTime()
            val dt = if (lastNs == 0L) 0f else (now - lastNs) / 1e9f
            lastNs = now
            val s = settings

            engine.step(dt)
            synchronized(lock) { engine.levels(snapshot) }
            if (engine.shapeIndex != currentShape) {
                currentShape = engine.shapeIndex
                main.post { refreshNotification() }
            }

            val g = glyph
            if (g != null && g.ready) {
                pushAcc += dt
                val period = 1f / s.matrixFps
                if (pushAcc >= period) {
                    pushAcc = min(pushAcc - period, period)
                    engine.toLed(led, scratch)
                    g.push(led)
                }
            }

            val away = detachedAt
            if (!uiAttached && away > 0L && s.sleepMinutes > 0 &&
                SystemClock.uptimeMillis() - away > s.sleepMinutes * 60_000L) {
                main.post { stopPlayback() }
                return
            }
            val delay = if (uiAttached) 16L else (1000L / s.matrixFps).coerceAtLeast(8L)
            render.postDelayed(this, delay)
        }
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate() {
        super.onCreate()
        settings = SettingsStore.load(this)
        val s = settings
        render.post { engine.apply(s) }
        currentShape = s.shape
        createChannel()
        running = true
        render.post(tick)
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopPlayback()
            ACTION_NEXT -> {
                render.post { engine.nextShape() }
                if (!foreground && !uiAttached) stopSelf()
            }
            else -> {                       // ACTION_PLAY
                enterForeground()
                ensureGlyph()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        render.removeCallbacksAndMessages(null)
        releaseGlyph()
        releaseWake()
        thread.quitSafely()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ API for the activity (main thread)

    fun attachUi(listener: (String) -> Unit) {
        uiAttached = true
        detachedAt = 0L
        statusListener = listener
        releaseWake()
        ensureGlyph()
        listener(lastStatus.ifEmpty { idleText() })
    }

    fun detachUi() {
        uiAttached = false
        statusListener = null
        detachedAt = SystemClock.uptimeMillis()
        if (foreground && settings.screenOff) acquireWake()
    }

    fun apply(s: ScopeSettings) {
        val old = settings
        settings = s
        render.post { engine.apply(s) }
        if (old.mirror != s.mirror) { if (s.mirror) ensureGlyph() else releaseGlyph() }
    }

    fun snapshot(dst: FloatArray) {
        synchronized(lock) { System.arraycopy(snapshot, 0, dst, 0, min(dst.size, snapshot.size)) }
    }

    fun drag(dYaw: Float, dPitch: Float, dt: Float) = render.post { engine.drag(dYaw, dPitch, dt) }
    fun release() = render.post { engine.release() }
    fun nextShape() = render.post { engine.nextShape() }

    fun leaveForeground() {
        if (foreground) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            foreground = false
        }
        releaseWake()
        stopSelf()      // still alive while the activity is bound
    }

    // ------------------------------------------------------------------ internals

    private fun stopPlayback() {
        releaseGlyph()
        setStatus("Stopped from the notification")
        leaveForeground()
    }

    private fun ensureGlyph() {
        if (!settings.mirror) { setStatus(idleText()); return }
        if (glyph == null) glyph = GlyphLink(this) { setStatus(it) }
        glyph?.connect()
    }

    private fun releaseGlyph() {
        glyph?.release()
        glyph = null
        setStatus(idleText())
    }

    private fun idleText() =
        if (Device.hasMatrix) "Glyph Matrix off" else "No Glyph Matrix on this device: preview only"

    private fun setStatus(s: String) {
        lastStatus = s
        statusListener?.invoke(s)
    }

    private fun enterForeground() {
        if (foreground) return
        startForeground(NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        foreground = true
    }

    private fun acquireWake() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(PowerManager::class.java) ?: return
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "phosphore:playback").apply {
            setReferenceCounted(false)
            val mins = settings.sleepMinutes
            acquire(if (mins > 0) mins * 60_000L + 5_000L else 6 * 60 * 60_000L)
        }
    }

    private fun releaseWake() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Throwable) { }
        wakeLock = null
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(NotificationChannel(
            CHANNEL, "Playback", NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Shown while Phosphore keeps the Glyph Matrix running"
            setShowBadge(false)
        })
    }

    private fun refreshNotification() {
        if (!foreground) return
        getSystemService(NotificationManager::class.java)?.notify(NOTIF_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        fun action(act: String, req: Int) = PendingIntent.getService(
            this, req, Intent(this, PlayerService::class.java).setAction(act),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val name = Shapes.all.getOrNull(currentShape)?.name ?: "Phosphore"
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(name)
            .setContentText("Playing on the Glyph Matrix")
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .addAction(Notification.Action.Builder(null as Icon?, "Next trace", action(ACTION_NEXT, 1)).build())
            .addAction(Notification.Action.Builder(null as Icon?, "Stop", action(ACTION_STOP, 2)).build())
            .build()
    }

    companion object {
        const val ACTION_PLAY = "com.adrienby.phosphore.PLAY"
        const val ACTION_NEXT = "com.adrienby.phosphore.NEXT"
        const val ACTION_STOP = "com.adrienby.phosphore.STOP"
        private const val CHANNEL = "playback"
        private const val NOTIF_ID = 1
    }
}
