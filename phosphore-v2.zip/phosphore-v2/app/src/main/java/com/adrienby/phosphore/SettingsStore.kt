package com.adrienby.phosphore

import android.content.Context
import com.adrienby.phosphore.engine.ScopeSettings
import java.io.File
import java.util.Properties

/**
 * Plain properties file instead of SharedPreferences: the Always-on toy runs in its own
 * process (":toy") and SharedPreferences caches per process.
 */
object SettingsStore {
    private const val NAME = "scope.properties"

    fun load(ctx: Context): ScopeSettings {
        val f = File(ctx.filesDir, NAME)
        if (!f.exists()) return ScopeSettings()
        val p = Properties()
        return try {
            f.inputStream().use { p.load(it) }
            val d = ScopeSettings()
            fun fl(k: String, def: Float) = p.getProperty(k)?.toFloatOrNull()?.coerceIn(0f, 1f) ?: def
            fun i(k: String, def: Int) = p.getProperty(k)?.toIntOrNull() ?: def
            fun b(k: String, def: Boolean) = p.getProperty(k)?.toBooleanStrictOrNull() ?: def
            ScopeSettings(
                shape = i("shape", d.shape),
                autoCycle = i("autoCycle", d.autoCycle),
                shuffle = b("shuffle", d.shuffle),
                spinMode = i("spinMode", d.spinMode).coerceIn(0, 2),
                rotation = fl("rotation", d.rotation),
                size = fl("size", d.size),
                sweep = fl("sweep", d.sweep),
                bandwidth = fl("bandwidth", d.bandwidth),
                focus = fl("focus", d.focus),
                persistence = fl("persistence", d.persistence),
                intensity = fl("intensity", d.intensity),
                contrast = fl("contrast", d.contrast),
                depth = fl("depth", d.depth),
                noise = fl("noise", d.noise),
                breathing = fl("breathing", d.breathing),
                mirror = b("mirror", d.mirror),
                background = b("background", d.background),
                screenOff = b("screenOff", d.screenOff),
                sleepMinutes = i("sleepMinutes", d.sleepMinutes),
                matrixFps = i("matrixFps", d.matrixFps).coerceIn(5, 60),
                brightness = fl("brightness", d.brightness),
                invert = b("invert", d.invert),
                flipX = b("flipX", d.flipX),
                rotate = i("rotate", d.rotate).let { if (it in listOf(0, 90, 180, 270)) it else 0 },
                aodMinutes = i("aodMinutes", d.aodMinutes),
            )
        } catch (_: Throwable) {
            ScopeSettings()
        }
    }

    fun save(ctx: Context, s: ScopeSettings) {
        val p = Properties()
        fun put(k: String, v: Any) { p.setProperty(k, v.toString()) }
        put("shape", s.shape); put("autoCycle", s.autoCycle); put("shuffle", s.shuffle)
        put("spinMode", s.spinMode); put("rotation", s.rotation); put("size", s.size)
        put("sweep", s.sweep); put("bandwidth", s.bandwidth); put("focus", s.focus)
        put("persistence", s.persistence); put("intensity", s.intensity); put("contrast", s.contrast)
        put("depth", s.depth); put("noise", s.noise); put("breathing", s.breathing)
        put("mirror", s.mirror); put("background", s.background); put("screenOff", s.screenOff)
        put("sleepMinutes", s.sleepMinutes); put("matrixFps", s.matrixFps); put("brightness", s.brightness)
        put("invert", s.invert); put("flipX", s.flipX); put("rotate", s.rotate)
        put("aodMinutes", s.aodMinutes)
        try {
            val target = File(ctx.filesDir, NAME)
            val tmp = File(ctx.filesDir, "$NAME.tmp")
            tmp.outputStream().use { p.store(it, null) }
            if (!tmp.renameTo(target)) {
                target.delete()
                if (!tmp.renameTo(target)) target.outputStream().use { p.store(it, null) }
            }
        } catch (_: Throwable) { }
    }

    /** Lets the toy process notice edits made in the app while it's already running. */
    fun stamp(ctx: Context): Long = File(ctx.filesDir, NAME).lastModified()
}
