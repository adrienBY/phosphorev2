plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.adrienby.phosphore"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.adrienby.phosphore"
        minSdk = 34
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }

    // Fixed debug key committed in /signing so every CI build installs over the previous one.
    signingConfigs {
        getByName("debug") {
            storeFile = rootProject.file("signing/debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Fetched by CI from Nothing-Developer-Programme/GlyphMatrix-Developer-Kit
    implementation(files("libs/glyph-matrix-sdk-2.0.aar"))
}
